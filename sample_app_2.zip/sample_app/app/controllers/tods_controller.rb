class TodsController < ApplicationController
  def new
    # Viewへ渡すためのインスタンス変数に空のモデルオブジェクトを生成する。
    @All = All.new
  end
# 以下を追加
  def create
    All = All.new(list_params)
    All.save

    # redirect_to '/top' を削除して、以下コードに変更
    # 詳細画面へリダイレクト
    redirect_to tods_path(list.id)
  end

  private
  # ストロングパラメータ
  def All_params
    params.require(:list).permit(:title, :body)
  end
end