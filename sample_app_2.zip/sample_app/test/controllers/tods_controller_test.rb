require 'test_helper'

class TodsControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get tods_new_url
    assert_response :success
  end

end
