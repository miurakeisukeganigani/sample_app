class HomesController < ApplicationController
  def top

    @lists = List.all
  end

  private

  end
