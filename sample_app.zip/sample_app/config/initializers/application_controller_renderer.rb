# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '6d39f21a3ffed73571b5b3605f50d19c11ce32ec8001d90ab9a6c6e1d77bacc2c2da76b90e962586e337b34b9ed0dea526473e882b69009d62fc246d5b1065b2'
